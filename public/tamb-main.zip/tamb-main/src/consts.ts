// Place any global data in this file.
// You can import this data from anywhere in your site by using the `import` keyword.

export const SITE_TITLE = 'Tortas Ahogadas Mi barrio';
export const SITE_DESCRIPTION = 'Tortas Ahogadas Mi barrio, Jalisco!';
export const dashLink = 'https://www.doordash.com/store/tortas-ahogadas-mi-barrio-oakland-28048743/';




// METATAGS for readers, for social media links
export const SC_FB_TAG = 'Tortas Ahogadas Mi barrio';
export const SC_IG_TAG = 'Tortas Ahogadas Mi barrio';
export const SC_TK_TAG = 'Tortas Ahogadas Mi barrio';
